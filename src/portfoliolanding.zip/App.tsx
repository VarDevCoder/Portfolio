import ParallaxSection from './components/ParallaxSection';
import ParticulasFondo from './components/ParticulasFondo';

function App() {
return (
  <>
    <div className="relative font-sans text-white">
      <ParticulasFondo />

      <header className="p-6 bg-transparent z-10 relative">
        <h1 className="text-3xl font-bold">Bienvenido a mi Portfolio</h1>
      </header>

      <ParallaxSection image="/parallax.avif">
        <h2 className="text-4xl text-center px-4">
           Explora mis proyectos y habilidades.
        </h2>
      </ParallaxSection>

      <section className="bg-negro text-white p-8">
        <h2 className="text-2xl font-semibold mb-4">Sobre mí</h2>
        <p>
          Soy un apasionado del desarrollo Web y la innovación tecnológica en casi todos los sectores que esta abarca.
        </p>
      </section>

      <footer className="p-6 bg-transparent z-10 relative">
        Osmar Martinez
      </footer>
    </div>
    <button className="bg-purpura text-negro hover:bg-amarillo font-bold px-6 py-2 rounded">
      ¡Contratame ya!
    </button>
  </>
);
}
export default App;
