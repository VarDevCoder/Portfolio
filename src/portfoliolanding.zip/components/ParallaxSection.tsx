// src/components/ParallaxSection.tsx
import { Parallax } from 'react-parallax';

interface ParallaxSectionProps {
  image: string;
  children: React.ReactNode;
}

export default function ParallaxSection({ image, children }: ParallaxSectionProps) {
  return (
    <Parallax bgImage={image} strength={600}>
      <div className="h-[500px] flex items-center justify-center text-white text-3xl font-bold">
        {children}
      </div>
    </Parallax>
  );
}
